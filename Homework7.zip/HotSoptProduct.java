public interface HotSoptProduct {

    public void method(String name);

}
