public class ChongQingHotSopt implements HotSoptProduct
{
    @Override
    public void method(String name)
    {
        System.out.println(name + "火锅");
    }
}
