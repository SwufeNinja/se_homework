public interface HotSopt {

    public HotSoptProduct produce();

}
